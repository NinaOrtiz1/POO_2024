def borrarPantalla():
  import os  
  os.system("cls")

def esperarTecla():
  print("\n \t \t Oprima cualquier tecla para continuar ...")
  input()
